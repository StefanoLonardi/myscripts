#!/usr/bin/python
import os, string

totalkmers = 0
k = 22
h1 = open('./cowpea91x.trimmedReads.fasta', 'r') 
#h1 = open('./test.fasta', 'r')
done = 0
totallen = 0
name = h1.readline() # > ....
if not name:
  done = 1
# print name.strip()
number = 1
while done == 0:
  sequence = h1.readline() # ACTCTTACTAT
  if not sequence:
    done = 1
  leng = len(sequence)-1
  # print 'added', len(sequence)-1, 'total', leng
  indone = 0
  while indone == 0:
    sequence = h1.readline() # ACTCTTACTAT
    if not sequence:
      indone = 1
      done = 1
      continue
    if sequence[0] == '>':
      # print sequence.strip()
      number += 1
      indone = 1
      continue
    leng += len(sequence)-1
    # print 'added', len(sequence)-1, 'total', leng
  # print 'total length', leng
  if (leng - k + 1) > 0:
    totalkmers += leng - k + 1
  totallen += leng
print 'totallen', totallen
print 'number of sequences', number
print 'total', k,'-mers', 'is', totalkmers
h1.close()
