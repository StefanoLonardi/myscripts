#!/usr/bin/python
#
# scan all the vu1/2 pools and prints
# the script to map them to the assembly
#

import os
from glob import glob

def main():
	x = getFiles('./vu2_pools')
	print "#/bin/csh"
        one = "cat "
	two = "cat "
	for i in range(91): 
               	#print "###### Processing "+x[i*3]+" "+x[i*3+1]+" "+x[i*3+2]
		one = one + x[i*3] + " "
		two = two + x[i*3+1] + " "
	print one + " > vu2_all_1"
	print two + " > vu2_all_2"

def getFiles(dire):
	files = []
	for fil in sorted(glob(dire + '/vu*')):
		files.append(fil.strip())
	return files
	
	
if __name__ == "__main__":
	main()
