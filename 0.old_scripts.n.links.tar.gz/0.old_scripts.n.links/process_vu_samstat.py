#!/usr/bin/python
#
# scan all the vu1/2 pools and prints
# the script to map them to the assembly
#

import os
from glob import glob

def main():
	x = getFiles('./vu1')
	samstat = "/home/stelo/bin/samtools flagstat "
	print "#/bin/csh"
	for i in range(91): # scan all the different SMRT cells directory
               	print "###### Processing "+x[i]
		print "echo \"" + x[i] + "\" >> ./out.stat.txt"
		print samstat + x[i] +" >> ./out.stat.txt"
		print

def getFiles(dire):
	files = []
	for fil in sorted(glob(dire + '/vu*')):
		files.append(fil.strip())
	return files
	
	
if __name__ == "__main__":
	main()
