#! /usr/bin/perl -w

###
### Script Name : filter.pl
### Input       : A fasta sequence file and the minimum length of sequence to consider 
### Output      : A fasta sequence file where each read is no less than filter
###

use strict;
use Getopt::Long;
use Bio::SeqIO;

my $fasta_file;
my $filter_length;
my $genome_size;

GetOptions("fasta_file=s" => \$fasta_file, "length_filter=i" => \$filter_length);
die "Usage: $0 [options]
\t\t-f /path/to/fasta/file [Req]
\t\t-l min contig length (0 if no filter is to be done) [Req]\n\n" if !$fasta_file || !defined($filter_length) || $filter_length !~ /\d+/;

#printf ("filter = $filter_length \n");

###
### Get the length of each sequence:
###
my $in = Bio::SeqIO->new(-file => $fasta_file, -format => 'fasta');
while (my $seq_obj = $in->next_seq){
	next if length($seq_obj->seq) < $filter_length;
	print ">",$seq_obj->id,"\n",$seq_obj->seq,"\n";
}

