#/bin/csh
export LD_LIBRARY_PATH=/24-2/home/stelo/pitchfork/deployment/lib:$LD_LIBRARY_PATH
export PATH=/24-2/home/stelo/pitchfork/deployment/bin:$PATH
#samtools faidx ./cowpea57x_fast_erate0.025_v1.2/cowpea.contigs.fasta
variantCaller -j 20 --algorithm=arrow ./cowpea57x_fast_erate0.025_v1.2/A.allpacked.cmp.h5 -r ./cowpea57x_fast_erate0.025_v1.2/cowpea.contigs57x.fasta -o ./cowpea57x_fast_erate0.025_v1.2/cowpea.variants.gff -o ./cowpea57x_fast_erate0.025_v1.2/cowpea.consensus.fasta -o ./cowpea57x_fast_erate0.025_v1.2/cowpea.consensus.fastq

# CHECK http://zombie.cb.k.u-tokyo.ac.jp/sprai/README.html#postprocessing
