#!/usr/bin/python
#
# scan all the cowpea assemblies in /inputdata/cowpea/pacbio/ and prints
# the script to map them to the assembly and merge the results
#

import os
from glob import glob

def main():
	cowpea_dirs = getFiles('/inputdata/cowpea/pacbio/')
        pbalign = "/24-2/home/stelo/pitchfork/deployment/bin/pbalign --forQuiver --nproc 20 "
        assembly = "cowpea57x_fast_erate0.025_v1.2"
        reference = " /24-2/home/stelo/CANU/"+assembly+"/cowpea.contigs.fasta "
	list_cowpea = [] 
	for x in cowpea_dirs: # scan all the different SMRT cells directory
		if x[-3:] != ".gz": # exclude the .gz files
			cell_name = x.split('/')[4] # e.g., A05_1
			#print cell_name
			cowpea_files = getFiles(x+'/Analysis_Results/')
			for y in cowpea_files:
				if y[-6:] == "bas.h5": # there must be this file in there
					sp = y.split('/')
					di = "/"+sp[1]+"/"+sp[2]+"/"+sp[3]+"/"+sp[4]+"/"+sp[5]+"/"
					idd = sp[6] # get the filename
					list_cowpea.append((cell_name,di,idd[:-7]))
	# generate the script
        print "#/bin/csh"
        #os.system("export LD_LIBRARY_PATH=/24-2/home/stelo/pitchfork/deployment/lib:$LD_LIBRARY_PATH")
        print "export LD_LIBRARY_PATH=/24-2/home/stelo/pitchfork/deployment/lib:$LD_LIBRARY_PATH"
        #os.system("export PATH=/24-2/home/stelo/pitchfork/deployment/bin:$PATH")
	print "export PATH=/24-2/home/stelo/pitchfork/deployment/bin:$PATH"
	for x in list_cowpea: # iterate through all SMRT cell dataset
                print "###### Processing "+x[0]
                input_file1 = x[1]+x[2]+".1.bax.h5"
                output_file1 = "/24-2/home/stelo/CANU/" + assembly + "/" + x[0] + ".1.cmp.h5"
                input_file2 = x[1]+x[2]+".2.bax.h5"
                output_file2 = "/24-2/home/stelo/CANU/" + assembly + "/" + x[0] + ".2.cmp.h5"
                input_file3 = x[1]+x[2]+".3.bax.h5"
                output_file3 = "/24-2/home/stelo/CANU/" + assembly + "/" + x[0] + ".3.cmp.h5"
                cmd1 = pbalign + input_file1 + reference + output_file1 
                print cmd1
                #os.system(cmd1)
                cmd2 = pbalign + input_file2 + reference + output_file2 
                print cmd2
                #os.system(cmd2)
                cmd3 = pbalign + input_file3 + reference + output_file3 
                print cmd3
                #os.system(cmd3)
                merge_cmd = "cmph5tools.py merge --outFile ./"+assembly+"/"+x[0]+".all.cmp.h5 "+ output_file1 + " " + output_file2 + " " + output_file3
                print merge_cmd
		#os.system(merge_cmd)
                sort_cmd = "cmph5tools.py sort --deep ./"+assembly+"/"+x[0]+".all.cmp.h5"
                print sort_cmd
		#os.system(sort_cmd)
                repack_cmd = "h5repack -f GZIP=1 ./"+assembly+"/"+x[0]+".all.cmp.h5 ./"+assembly+"/"+x[0]+".acked.cmp.h5 &"
                print repack_cmd
		#os.system(repack_cmd)
		print

def getFiles(dire):
	files = []
	for fil in sorted(glob(dire + '/*')):
		files.append(fil.strip())
	return files
	
	
if __name__ == "__main__":
	main()
