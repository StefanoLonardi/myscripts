./filter.pl -f ./cowpea_wgs_assembly/soap.contig -l 500 > filtered.contig.fasta
